import React from "react";
import "./Footer.css";
function Footer() {
  return (
    <div className="footer">
    </div>
  );
}

export default Footer;
